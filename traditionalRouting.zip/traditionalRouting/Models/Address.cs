﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace traditionalRouting.Models {
    public class Address {
        public string HomeNumber { get; set; }
        public string Address1 { get; set; }
        public string City { get; set; }
    }
}